<!-- Optional JavaScript -->
<script src="{{ url('frontend/libraries/fontawesome/js/all.min.js') }}"></script>

<script src="{{ url('frontend/libraries/jquery/jquery.min.js') }}"></script>
<script src="{{ url('frontend/libraries/popper/popper.min.js') }}"></script>
<script src="{{ url('frontend/libraries/bootstrap/js/bootstrap.js') }}"></script>
<script src="{{ url('frontend/libraries/retina/retina.min.js') }}"></script>
<script src="{{ url('frontend/scripts/main.js') }}"></script>