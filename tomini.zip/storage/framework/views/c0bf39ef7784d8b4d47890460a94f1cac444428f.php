
<?php $__env->startSection('title', 'Checkout Success'); ?>

<?php $__env->startSection('content'); ?>
<main>
    <div class="section-success d-flex align-items-center">
        <div class="col text-center">
        <img src="<?php echo e(url('frontend/images/icon_success_checkout 2.png')); ?>" alt="">
            <h1>Yay! Success</h1>
            <p>
                We've sent you email for trip
                <br>
                instructions please read it as well
            </p>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-home-page mt-3 px-5">
            <i class="fas fa-home mr-2"></i>
            Home Page
        </a>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tomini\resources\views/pages/success.blade.php ENDPATH**/ ?>