<!-- jQuery  -->
<script src="<?php echo e(url('/backend/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/js/metismenu.min.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/js/waves.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/js/feather.min.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/js/jquery.slimscroll.min.js')); ?>"></script> 

<script src="<?php echo e(url('/backend/assets/plugins/moment/moment.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/plugins/chartjs/chart.min.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/plugins/chartjs/roundedBar.min.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/plugins/lightpick/lightpick.js')); ?>"></script>
<script src="<?php echo e(url('/backend/assets/pages/jquery.sales_dashboard.init.js')); ?>"></script>

<!-- App js -->
<script src="<?php echo e(url('/backend/assets/js/app.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\tomini\resources\views/includes/admin/script.blade.php ENDPATH**/ ?>