

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Page-Title -->
            <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between">
            <h1 class="h3 mb-0 text-gray-800 mt-4 mb-4">Gallery</h1>
        </div>
        <!-- end page title end breadcrumb -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <a class="btn btn-primary btn-square btn-outline-dashed waves-effect waves-light mb-3" href="<?php echo e(route('gallery.create')); ?>">
                            <i class="fas fa-plus mr-1"></i>
                            Tambah Gallery
                        </a>
                        <div class="table-responsive">
                            <table class="table  table-bordered">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Travel</th>
                                    <th>Gambar</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->travel_package->title); ?></td>
                                        <td>
                                            <img src="<?php echo e(Storage::url($item->image)); ?>" alt="" style="width: 150px" class="img-thumbnail" />
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('gallery.edit', $item->id)); ?>" class="btn btn-secondary btn-square btn-outline-dashed waves-effect waves-light">
                                                <i class="fas fa-pencil-alt"></i>
                                            </a>
                                            <form action="<?php echo e(route('gallery.destroy', $item->id)); ?>" method="post" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-danger btn-square btn-outline-dashed waves-effect waves-light">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">
                                            Data Kosong
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div><!--end table-->     
                    </div><!--end card-body-->
                </div><!--end card-->
            </div> <!-- end col -->
        </div> <!-- end row -->
    </div>
    <!-- container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tominima/laravel/resources/views/pages/admin/gallery/index.blade.php ENDPATH**/ ?>