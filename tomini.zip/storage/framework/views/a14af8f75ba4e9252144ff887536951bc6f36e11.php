<footer class="footer text-center">
    &copy; 2020 TOMINI TOUR & TRAVEL <span class="text-muted d-none d-sm-inline-block"><i class="fas fa-code text-danger mr-1"></i>Design by Yubli Audy Warokka</span>
</footer><!--end footer--><?php /**PATH /home/tominima/laravel/resources/views/includes/admin/footer.blade.php ENDPATH**/ ?>