<!-- Optional JavaScript -->
<script src="<?php echo e(url('frontend/libraries/fontawesome/js/all.min.js')); ?>"></script>

<script src="<?php echo e(url('frontend/libraries/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('frontend/libraries/popper/popper.min.js')); ?>"></script>
<script src="<?php echo e(url('frontend/libraries/bootstrap/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(url('frontend/libraries/retina/retina.min.js')); ?>"></script>
<script src="<?php echo e(url('frontend/scripts/main.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\tomini\resources\views/includes/script.blade.php ENDPATH**/ ?>