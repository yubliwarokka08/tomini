<!-- Top Bar Start -->
<div class="topbar">

    <!-- LOGO -->
    <div class="topbar-left">
        <a class="navbar-brand mt-2" href="<?php echo e(route('dashboard')); ?>">
            <img src="<?php echo e(url('backend/assets/images/logo-dark.png')); ?>" width="150" height="35" alt="">
          </a>
    </div>
    <!--end logo-->
<!-- Navbar -->
<nav class="navbar-custom">    
    <ul class="list-unstyled topbar-nav float-right mb-0"> 
        

        <li class="dropdown">
            <a class="nav-link dropdown-toggle waves-effect waves-light nav-user" data-toggle="dropdown" href="#" role="button"
                aria-haspopup="false" aria-expanded="false">
                <img src="<?php echo e(url('backend/assets/images/users/user-1.png')); ?>" alt="profile-user" class="rounded-circle" /> 
                <span class="ml-1 nav-user-name hidden-sm"><?php echo e(Auth::user()->name); ?><i class="mdi mdi-chevron-down"></i> </span>
            </a>
            <!-- Dropdown - User Information -->
        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
              <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
              Logout
            </a>
          </div>
        </li>
    </ul><!--end topbar-nav-->
</nav>
<!-- end navbar-->
</div>
<!-- Top Bar End --><?php /**PATH /home/tominima/laravel/resources/views/includes/admin/navbar.blade.php ENDPATH**/ ?>