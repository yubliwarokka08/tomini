<!-- Left Sidenav -->
<div class="left-sidenav">
    <ul class="metismenu left-sidenav-menu">
        <li>
            <a href="#"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
        </li>
        <li>
            <a href="#"><i class="fas fa-hotel"></i><span>Paket Travel</span></a>
        </li>
        <li>
            <a href="#"><i class="fas fa-images"></i><span>Galeri</span></a>
        </li>
        <li>
            <a href="#"><i class="fas fa-dollar-sign"></i><span>Transaksi</span></a>
        </li>
    </ul>
</div>
<!-- end left-sidenav--><?php /**PATH C:\xampp\htdocs\tomini\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>