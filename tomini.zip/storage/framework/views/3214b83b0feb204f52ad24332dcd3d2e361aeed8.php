<footer class="footer text-center">
    <div class="boxed-footer">
        &copy;Copyright 2020 Tomini.ID <span class="text-muted d-none d-sm-inline-block mr-2 ml-2"> <i class="fas fa-code text-danger"></i> Design by Yubli Audy Warokka</span>
    </div>                    
</footer><!--end footer-->

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <form action="<?php echo e(url('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <button class="btn btn-primary" type="submit"">Logout</button>
        </form>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\tomini\resources\views/includes/admin/footer.blade.php ENDPATH**/ ?>