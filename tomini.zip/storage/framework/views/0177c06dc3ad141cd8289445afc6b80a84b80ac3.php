
<?php $__env->startSection('title', 'Details Travel'); ?>

<?php $__env->startSection('content'); ?>
<main>
    <section class="section-details-header"></section>
    <section class="section-details-content">
        <div class="container">
            <div class="row">
                <div class="col p-0">
                    <nav>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                Paket Travel
                            </li>
                            <li class="breadcrumb-item active">
                                Details
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8 pl-lg-0">
                    <div class="card card-details">
                        <h1>Dubai</h1>
                        <p>United Arab Emirates</p>
                        <div class="gallery">
                            <div class="xzoom-container">
                                <img src="<?php echo e(url('frontend/images/pic_details.jpg')); ?>" class="xzoom" id="xzoom-default"
                                    xoriginal="<?php echo e(url('frontend/images/pic_details.jpg')); ?>">
                            </div>
                            <div class="xzoom-thumbs">
                                <a href="<?php echo e(url('frontend/images/pic_details.jpg')); ?>">
                                    <img src="<?php echo e(url('frontend/images/pic_details.jpg')); ?>" class="xzoom-gallery" width="120"
                                        xpreview="<?php echo e(url('frontend/images/pic_details.jpg')); ?> ">
                                </a>
                                <a href="<?php echo e(url('frontend/images/pic_details1.jpg')); ?>">
                                    <img src="<?php echo e(url('frontend/images/pic_details1.jpg')); ?>" class="xzoom-gallery" width="120"
                                        xpreview="<?php echo e(url('frontend/images/pic_details1.jpg')); ?> ">
                                </a>
                                <a href="<?php echo e(url('frontend/images/pic_details2.jpg')); ?>">
                                    <img src="<?php echo e(url('frontend/images/pic_details2.jpg')); ?>" class="xzoom-gallery" width="120"
                                        xpreview="<?php echo e(url('frontend/images/pic_details2.jpg')); ?>">
                                </a>
                                <a href="<?php echo e(url('frontend/images/pic_details3.jpg')); ?>">
                                    <img src="<?php echo e(url('frontend/images/pic_details3.jpg')); ?>" class="xzoom-gallery" width="120"
                                        xpreview="<?php echo e(url('frontend/images/pic_details3.jpg')); ?>">
                                </a>
                                <a href="<?php echo e(url('frontend/images/pic_details4.jpg')); ?>">
                                    <img src="<?php echo e(url('frontend/images/pic_details4.jpg')); ?>" class="xzoom-gallery" width="120"
                                        xpreview="<?php echo e(url('frontend/images/pic_details4.jpg')); ?>">
                                </a>
                            </div>
                        </div>
                        <h2>
                            About Dubai Tourism
                        </h2>
                        <p>
                            Burj Al Arab, Dubai is a luxury hotel located in Dubai, United Arab Emirates. The Burj
                            al-Arab
                            building, designed by Tom Wright, reaches a height of 321 meters and is the tallest
                            building
                            fully used as a hotel. This building stands on an artificial island which is 280 m off
                            the
                            coast
                            in the Persian Gulf. The Burj al-Arab is owned by Jumeirah.
                        </p>
                        <p>
                            The hotel frequently called as a seven rate star hotel. This is considered a hyperbole
                            by
                            people in the field of tourism. This is also seen as a way to "beat" other hotels that
                            call
                            their
                            hotels six stars. Unfortunately, almost all hotel ranking systems in the world have a
                            five
                            star
                            limit. According to the official Burj al-Arab website, this hotel is "five star deluxe
                            hotel".
                        </p>
                        <div class="features row">
                            <div class="col-md-4">
                                <img src="<?php echo e(url('frontend/images/icon_event.png')); ?>" alt="" class="features-image">
                                <div class="description">
                                    <h3>
                                        Featured Events
                                    </h3>
                                    <p>
                                        No Events
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-4 border-left">
                                <img src="<?php echo e(url('frontend/images/icon_language.png')); ?>" alt="" class="features-image">
                                <div class="description">
                                    <h3>
                                        Language
                                    </h3>
                                    <p>
                                        Arab Language
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-4 border-left">
                                <img src="<?php echo e(url('frontend/images/icon_foods.png')); ?>" alt="" class="features-image">
                                <div class="description">
                                    <h3>
                                        Foods
                                    </h3>
                                    <p>
                                        Arabian Foods
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card card-details card-right">
                        <h2>Members are going</h2>
                        <div class="members my-2">
                            <img src="<?php echo e(url('frontend/images/user_pic1.png')); ?>" class="member-image mr-1">
                            <img src="<?php echo e(url('frontend/images/user_pic2.png')); ?>" class="member-image mr-1">
                            <img src="<?php echo e(url('frontend/images/user_pic3.png')); ?>" class="member-image mr-1">
                            <img src="<?php echo e(url('frontend/images/user_pic4.png')); ?>" class="member-image mr-1">
                            <img src="<?php echo e(url('frontend/images/user9+.png')); ?>" class="member-image mr-1">
                        </div>
                        <hr>
                        <h2 class="mb-3">Trip Informations</h2>
                        <table class="trip-informations">
                            <tr>
                                <th width="50%">Date of Departure</th>
                                <td width="50%" class="text-right">
                                    04 May, 2020
                                </td>
                            </tr>
                            <tr>
                                <th width="50%">Duration</th>
                                <td width="50%" class="text-right">
                                    4D 3N
                                </td>
                            </tr>
                            <tr>
                                <th width="50%">Type</th>
                                <td width="50%" class="text-right">
                                    Open Trip
                                </td>
                            </tr>
                            <tr>
                                <th width="50%">Price</th>
                                <td width="50%" class="text-right">
                                    $80.00 / person
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="join-container">
                        <a href="<?php echo e(route('checkout')); ?>" class="btn btn-block btn-join-now mt-3 py-2">
                            Join Now
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('prepend.style'); ?>
<link rel="stylesheet" href="<?php echo e(url('frontend/libraries/xzoom/xzoom.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
<script src="<?php echo e(url('frontend/libraries/xzoom/xzoom.min.js')); ?>"></script>
<script>
    $(document).ready(function () {
        $('.xzoom, .xzoom-gallery').xzoom({
            zoomWidth: 500,
            title: false,
            tint: '#333',
            Xoffset: 15
        });
    });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tomini\resources\views/pages/details.blade.php ENDPATH**/ ?>