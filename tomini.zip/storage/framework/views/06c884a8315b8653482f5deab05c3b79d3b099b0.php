

<?php $__env->startSection('title'); ?>
    ABADI TOUR & TRAVEL
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <!-- Header -->
     <header class="text-center">
        <h1>
            It's time to go around the world with
            <br>
            a variety of tour packages
        </h1>
        <p class="mt-3">
            It's time to go around the world with
            <br>
            a variety of tour packages
        </p>
        <a href="#popular" class="btn btn-get-started px-4 mt-4">
            Get started
        </a>
    </header>

    <!-- Main Tag -->
    <main>
        <div class="container">
            <section class="section-stats row justify-content-center" id="stats">
                <div class="col-3 col-md-2 stats-detail">
                    <h2>20K</h2>
                    <p>Members</p>
                </div>
                <div class="col-3 col-md-2 stats-detail">
                    <h2>12</h2>
                    <p>Countries</p>
                </div>
                <div class="col-3 col-md-2 stats-detail">
                    <h2>3K</h2>
                    <p>Hotels</p>
                </div>
                <div class="col-3 col-md-2 stats-detail">
                    <h2>72</h2>
                    <p>Partners</p>
                </div>
            </section>
        </div>
        <section class="section-popular">
            <div class="container">
                <div class="row">
                    <div class="col text-center section-popular-heading">
                        <h2>
                            Our Popular To Package
                        </h2>
                        <p>
                            Somethink that you never try
                            <br>
                            before in this world
                        </p>
                    </div>
                </div>
            </div>
        </section>
        <section class="section-popular-content" id="popularContent">
            <div class="container">
                <div class="section-popular-travel row justify-content-center">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-md-4 col-lg-3">
                            <div class="card-travel text-center d-flex flex-column"
                                style="background-image: url('<?php echo e($item->galleries->count() ? Storage::url($item->galleries->first()->image) : ''); ?>');">
                                <div class="travel-country"><?php echo e($item->location); ?></div>
                                <div class="travel-location"><?php echo e($item->title); ?></div>
                                <div class="travel-button mt-auto">
                                    <a href="<?php echo e(route('detail', $item->slug)); ?>" class="btn btn-travel-details px-4">
                                        View Details
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <section class="section-partners" id="partners">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <h2>Our Partners</h2>
                        <p>
                            Some partners who have worked
                            <br>
                            with us, to handle our traveler.
                        </p>
                    </div>
                    <div class="col-md-8 text-center">
                        <img src="<?php echo e(url('frontend/images/our_parners.png')); ?>" alt="Logo Partner" class="img-partner">
                    </div>
                </div>
            </div>
        </section>
        <section class="section-testimonial-heading" id="testimonialHeading">
            <div class="container">
                <div class="row">
                    <div class="col text-center">
                        <h2>They're Loving Us</h2>
                        <p>
                            What do they say who have entrusted using
                            <br>
                            our travel services.
                        </p>
                    </div>
                </div>
            </div>
        </section>
        <section class="section section-testimonial-content" id="testimonialContent">
            <div class="container">
                <div class="section-popular-travel row justify-content-center">
                    <div class="col-sm-6 col-md-6 col-lg-4">
                        <div class="card card-testimonial text-center">
                            <div class="testimonial-content">
                                <img src="<?php echo e(url('frontend/images/user-pic1.png')); ?>" alt="User" class="mb-6 rounded-circle">
                                <h3 class="mb-6">Mark Austine</h3>
                                <img src="<?php echo e(url('frontend/images/star1.png')); ?>" alt="Rate" class="mb-6">
                                <p class="testimonial">
                                    "Post votum promissa memini
                                    cuius adeptione cupis; quem
                                    pollicitus est aversione aversi
                                    et fuga."
                                </p>
                            </div>
                            <hr>
                            <p class="trip-to mt-2">
                                Trip to Deratan Bali, Indonesia
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4">
                        <div class="card card-testimonial text-center">
                            <div class="testimonial-content">
                                <img src="<?php echo e(url('frontend/images/user-pic2.png')); ?>" alt="User" class="mb-6 rounded-circle">
                                <h3 class="mb-6">Mark Austine</h3>
                                <img src="<?php echo e(url('frontend/images/star2.png')); ?>" alt="Rate" class="mb-6">
                                <p class="testimonial">
                                    "Post votum promissa memini
                                    cuius adeptione cupis; quem
                                    pollicitus est aversione aversi
                                    et fuga."
                                </p>
                            </div>
                            <hr>
                            <p class="trip-to mt-2">
                                Trip to Bromo, Indonesia
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4">
                        <div class="card card-testimonial text-center">
                            <div class="testimonial-content">
                                <img src="<?php echo e(url('frontend/images/user-pic3.png')); ?>" alt="User" class="mb-6 rounded-circle">
                                <h3 class="mb-6">Mark Austine</h3>
                                <img src="<?php echo e(url('frontend/images/star3.png')); ?>" alt="Rate" class="mb-6">
                                <p class="testimonial">
                                    "Post votum promissa memini
                                    cuius adeptione cupis; quem
                                    pollicitus est aversione aversi
                                    et fuga."
                                </p>
                            </div>
                            <hr>
                            <p class="trip-to mt-2">
                                Trip to Dubai, Middle East
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <a href="#" class="btn btn-need-help px-4 mt-4 mx-1">
                            I Need Help
                        </a>
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-get-started px-4 mt-4 mx-1">
                            Get Started
                        </a>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tominima/laravel/resources/views/pages/home.blade.php ENDPATH**/ ?>