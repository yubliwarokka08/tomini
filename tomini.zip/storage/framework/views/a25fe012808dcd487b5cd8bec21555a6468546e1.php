<!-- Left Sidenav -->
<div class="left-sidenav mt-4">
    <ul class="metismenu left-sidenav-menu mt-2">
      <hr class="sidebar-divider">
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
              <i class="fas fa-fw fa-tachometer-alt"></i>
              <span>Dashboard</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('travel-package.index')); ?>">
              <i class="fas fa-fw fa-hotel"></i>
              <span>Paket Travel</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('gallery.index')); ?>">
              <i class="fas fa-fw fa-images"></i>
              <span>Galeri Travel</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('transaction.index')); ?>">
              <i class="fas fa-fw fa-dollar-sign"></i>
              <span>Transaksi</span></a>
          </li>

          <hr class="sidebar-divider">
          
    </ul>
</div>
<!-- end left-sidenav--><?php /**PATH /home/tominima/laravel/resources/views/includes/admin/sidebar.blade.php ENDPATH**/ ?>