<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo e(url('backend/assets/images/favicon.ico')); ?>">

    <link href="<?php echo e(url('backend/assets/plugins/jvectormap/jquery-jvectormap-2.0.2.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('backend/assets/plugins/lightpick/lightpick.css')); ?>" rel="stylesheet" />

    <!-- App css -->
    <link href="<?php echo e(url('backend/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('backend/assets/css/jquery-ui.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('backend/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('backend/assets/css/metisMenu.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('backend/assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" /><?php /**PATH /home/tominima/laravel/resources/views/includes/admin/style.blade.php ENDPATH**/ ?>