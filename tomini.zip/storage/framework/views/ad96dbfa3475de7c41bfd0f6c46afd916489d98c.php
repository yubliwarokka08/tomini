<link rel="stylesheet" href="<?php echo e(url('frontend/libraries/bootstrap/css/bootstrap.css')); ?>">
<link
    href="https://fonts.googleapis.com/css?family=Assistant:200,300,400,600,700,800|Playfair+Display:400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap"
    rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(url('frontend/styles/main.css')); ?>"><?php /**PATH /home/tominima/laravel/resources/views/includes/style.blade.php ENDPATH**/ ?>