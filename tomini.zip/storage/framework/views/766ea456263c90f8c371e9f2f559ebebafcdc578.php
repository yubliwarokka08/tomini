<footer class="section-footer mt-5 mb-4 border-top">
    <div class="container pt-5 pb-5">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="row">
                    <div class="col-12 col-lg-3">
                        <h5>FEATURES</h5>
                        <ul class="list-unstyled">
                            <li><a href="#">Reviews</a></li>
                            <li><a href="#">Community</a></li>
                            <li><a href="#">Social Media Kit</a></li>
                            <li><a href="#">Affiliates</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-lg-3">
                        <h5>ACCOUNT</h5>
                        <ul class="list-unstyled">
                            <li><a href="#">Refunds</a></li>
                            <li><a href="#">Security</a></li>
                            <li><a href="#">Rewards</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-lg-3">
                        <h5>COMPANY</h5>
                        <ul class="list-unstyled">
                            <li><a href="#">Career</a></li>
                            <li><a href="#">Help Center</a></li>
                            <li><a href="#">Media</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-lg-3">
                        <h5>GET CONNECTED</h5>
                        <ul class="list-unstyled">
                            <li><a href="#">Luwuk, Kabupaten Banggai</a></li>
                            <li><a href="#">Sulawesi Tengah,Indonesia</a></li>
                            <li><a href="#">94713</a></li>
                            <li><a href="#">WA: 0812-4553-6677</a></li>
                            <li><a href="#">yubliwarokka@gmail.com</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row border-top justify-content-center pt-4">
        <div class="col-auto text-gray-500 font-weight-light">
            2020 Copyrights AbadTour. Yubli Audy Warokka. All Rights Reserved. Made In Luwuk
        </div>
    </div>
</footer><?php /**PATH /home/tominima/laravel/resources/views/includes/footer.blade.php ENDPATH**/ ?>